insert into user(id,username,password,address,phone) values(1001L,'mahesh','mahesh123','Bangalore',9874635246L);
insert into user(id,username,password,address,phone) values(1002L,'rahesh','rahesh1223','chennai',9874635244L);
insert into user(id,username,password,address,phone) values(1003L,'sahesh','sahesh123','mumbai',9874635566L);
insert into user(id,username,password,address,phone) values(1004L,'suresh','suresh123','pune',9874635231L);
insert into user(id,username,password,address,phone) values(1005L,'mahi','mah123','Hydrabad',9874635687L);
